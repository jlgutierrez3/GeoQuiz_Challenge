package guti.li.jessi.geoquiz_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


/*AppCompatActivity is a sublcass of Android's Activity class that
  provides compatibility support for older
  versions of Android
*/
public class QuizActivity extends AppCompatActivity {

    private Button mTrueButton;
    private Button mFalseButton;


    /*public QuizActivity(Button mTrueButton) {
        this.mTrueButton = mTrueButton;

    }

    public QuizActivity(Button mFalseButton) {
        this.mFalseButton = mFalseButton;

    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        mTrueButton = (Button) findViewById(R.id.true_button);
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast=
                Toast.makeText(QuizActivity.this,
                        R.string.correct_toast,
                        Toast.LENGTH_SHORT);
                        toastPlacement(toast);
            }
        });



        mFalseButton = (Button) findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener()  {
            @Override
                public void onClick(View v) {
                    Toast toast=
                    Toast.makeText(QuizActivity.this,
                            R.string.incorrect_toast,
                            Toast.LENGTH_SHORT);
                            toastPlacement(toast);
            }
        });

    }
    //This was thought up by Darrin
    //create a method, let Toast t be the input
    //Add a way to Get the length and make it global
    //calculate the relative length away from the y axis top that you want
    private void toastPlacement(Toast t) {
        t.setGravity(Gravity.TOP,0,400);
        t.show();
    }



}
